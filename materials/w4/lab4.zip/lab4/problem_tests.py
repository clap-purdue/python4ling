# Python for Linguistics — Home Lab 1 Tests (Indentation & If Statements)
#
# Usage in notebook:
#     from problem_tests import *
#     test_problem_1(...)          # Test individual problems
#     run_all_tests(globals())     # Test everything at once (optional)
#
# Note about input():
# - Problem 4 uses input(), so its test checks that your computed variables
#   match the user's input (whatever the user typed).

def _pass(n, msg):
    print(f"✓ PROBLEM {n} CORRECT!")
    if msg:
        print(f"  {msg}")
    return True

def _fail(n, msg):
    print(f"✗ Problem {n}: {msg}")
    return False


def test_problem_1(password, is_strong):
    try:
        assert password == "purdue2026", "password should be exactly \"purdue2026\"."
        assert isinstance(is_strong, bool), "is_strong should be a boolean (True/False)."
        assert is_strong is True, "is_strong should be True when len(password) >= 8."
        return _pass(1, "Good! You used len() and an if/else to create a boolean.")
    except AssertionError as e:
        return _fail(1, str(e))


def test_problem_2(minutes_late, status):
    try:
        assert minutes_late == 17, "minutes_late should be 17."
        assert isinstance(status, str), "status should be a string."
        assert status in ["On time", "Late (within grace period)", "Late (penalty applies)"], "status must be one of the required strings."
        assert status == "Late (penalty applies)", "Because minutes_late > 15, status should be \"Late (penalty applies)\"."
        return _pass(2, "Nice! Your if/elif/else handles all three cases.")
    except AssertionError as e:
        return _fail(2, str(e))


def test_problem_3(score, letter_grade):
    try:
        assert score == 84, "score should be 84."
        assert letter_grade in ["A", "B", "C", "D", "F"], "letter_grade must be one of: A, B, C, D, F."
        assert letter_grade == "B", "84 should map to a B (80–89). Check your elif order."
        return _pass(3, "Great! Your grading logic is correct (and your elif order makes sense).")
    except AssertionError as e:
        return _fail(3, str(e))


def test_problem_4(sentence, char_count, token_count):
    try:
        assert isinstance(sentence, str), "sentence should be a string (from input())."
        assert char_count == len(sentence), "char_count should equal len(sentence)."
        if len(sentence) > 3:
            expected_tokens = len(sentence.split())
            assert token_count == expected_tokens, "When char_count > 3, token_count should equal len(sentence.split())."
        else:
            assert token_count == 0, "When char_count <= 3, token_count should be 0."
        return _pass(4, "Nice! You used input(), len(), split(), and indentation correctly.")
    except AssertionError as e:
        return _fail(4, str(e))


def test_problem_5(hungry, friend_is_there, has_time, will_go, message):
    try:
        assert hungry is False, "hungry should be False."
        assert friend_is_there is True, "friend_is_there should be True."
        assert has_time is True, "has_time should be True."
        assert isinstance(will_go, bool), "will_go should be a boolean."
        expected = (hungry or friend_is_there) and has_time
        assert will_go == expected, "will_go is incorrect. Check your (or) and (and) logic and parentheses."
        assert message in ["Let's go!", "Not today."], "message must be exactly \"Let's go!\" or \"Not today.\"."
        assert message == "Let's go!", "With these values, you should go, so message should be \"Let's go!\"."
        return _pass(5, "Great! You combined booleans with (or) and (and).")
    except AssertionError as e:
        return _fail(5, str(e))


def test_problem_6(utterance, sentence_type, note):
    try:
        assert utterance == "Where are you going?", "utterance should be exactly \"Where are you going?\"."
        assert sentence_type in ["question", "exclamation", "statement"], "sentence_type must be one of: question, exclamation, statement."
        assert sentence_type == "question", "Because the utterance ends with ?, sentence_type should be \"question\"."
        assert note in ["Looks like an interrogative.", "Not an interrogative."], "note must be one of the two required strings."
        assert note == "Looks like an interrogative.", "If sentence_type is question, note should be the interrogative message."
        return _pass(6, "Excellent! You used string indexing and if/elif/else correctly.")
    except AssertionError as e:
        return _fail(6, str(e))


