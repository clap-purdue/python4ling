# Python for Linguistics — Home Lab 3 Tests
#
# Usage in notebook:
#     from problem_tests import *
#     test_problem_1(...)        # Test individual problems
#     run_all_tests(globals())   # Test everything at once (optional)

def _pass(n, msg):
    print(f"✓ PROBLEM {n} CORRECT!")
    if msg:
        print(f"  {msg}")
    return True

def _fail(n, msg):
    print(f"✗ Problem {n}: {msg}")
    return False


def test_problem_1(word, length):
    """Test Problem 1: Word length"""
    try:
        assert isinstance(word, str), "word should be a string."
        assert word == "linguistics", "word should be 'linguistics'."
        assert length == 11, "length should be 11 (hint: use len(word))."
        return _pass(1, "Nice! You computed the string length correctly.")
    except AssertionError as e:
        return _fail(1, str(e))


def test_problem_2(text, first_char, last_char):
    """Test Problem 2: Indexing"""
    try:
        assert text == "Mandarin", "text should be 'Mandarin'."
        assert first_char == "M", "first_char should be the first character of text (hint: text[0])."
        assert last_char == "n", "last_char should be the last character of text (hint: text[-1])."
        return _pass(2, "Great! You indexed the first and last characters correctly.")
    except AssertionError as e:
        return _fail(2, str(e))


def test_problem_3(s, sub):
    """Test Problem 3: Slicing"""
    try:
        assert s == "computational", "s should be 'computational'."
        assert sub == "put", "sub should be 'put' (hint: use slicing s[start:end])."
        return _pass(3, "Good! Your slicing produced the correct substring.")
    except AssertionError as e:
        return _fail(3, str(e))


def test_problem_4(raw_name, clean_name):
    """Test Problem 4: strip + lower"""
    try:
        assert raw_name == "  JiNgYiNg  ", "raw_name should include the leading/trailing spaces exactly."
        assert clean_name == "jingying", "clean_name should be 'jingying' (hint: strip() then lower())."
        return _pass(4, "Perfect! You removed spaces and normalized the casing.")
    except AssertionError as e:
        return _fail(4, str(e))


def test_problem_5(msg, new_msg):
    """Test Problem 5: replace"""
    try:
        assert msg == "I like cats", "msg should be 'I like cats'."
        assert new_msg == "I like dogs", "new_msg should be 'I like dogs' (hint: use replace())."
        return _pass(5, "Nice! You replaced the target word correctly.")
    except AssertionError as e:
        return _fail(5, str(e))


def test_problem_6(nouns, verbs, report):
    """Test Problem 6: f-string formatting"""
    try:
        assert nouns == 450, "nouns should be 450."
        assert verbs == 320, "verbs should be 320."
        assert report == "Nouns: 450, Verbs: 320", "report does not match exactly (hint: use an f-string)."
        return _pass(6, "Great! Your formatted string matches the required output.")
    except AssertionError as e:
        return _fail(6, str(e))


def test_problem_7(vowels):
    """Test Problem 7: list creation"""
    try:
        assert isinstance(vowels, list), "vowels should be a list."
        assert vowels == ['a', 'e', 'i', 'o', 'u'], "vowels should be ['a', 'e', 'i', 'o', 'u']."
        return _pass(7, "Good! Your vowels list is correct.")
    except AssertionError as e:
        return _fail(7, str(e))


def test_problem_8(nums, first_num, last_two):
    """Test Problem 8: list indexing & slicing"""
    try:
        assert nums == [3, 7, 2, 9, 5], "nums should be [3, 7, 2, 9, 5]."
        assert first_num == 3, "first_num should be the first element of nums (hint: nums[0])."
        assert last_two == [9, 5], "last_two should be the last two elements (hint: nums[-2:])."
        return _pass(8, "Nice! You used list indexing and slicing correctly.")
    except AssertionError as e:
        return _fail(8, str(e))


def test_problem_9(items):
    """Test Problem 9: append"""
    try:
        assert items == ['apple', 'banana', 'cherry'], "items should end as ['apple', 'banana', 'cherry'] (hint: use append())."
        return _pass(9, "Great! You appended 'cherry' correctly.")
    except AssertionError as e:
        return _fail(9, str(e))


def test_problem_10(sentence, words, rejoined):
    """Test Problem 10: split + join"""
    try:
        assert sentence == "I love natural language processing", "sentence should match the required sentence."
        expected_words = ["I", "love", "natural", "language", "processing"]
        assert words == expected_words, "words should be the list produced by splitting sentence on spaces (hint: split())."
        assert rejoined == sentence, "rejoined should match the original sentence (hint: ' '.join(words))."
        return _pass(10, "Excellent! You used split() and join() correctly.")
    except AssertionError as e:
        return _fail(10, str(e))


def run_all_tests(ns):
    """Run all tests using a namespace dict (use globals() from the notebook)."""
    results = []
    def _safe(n, fn, *keys):
        try:
            args = [ns.get(k) for k in keys]
            return fn(*args)
        except Exception as e:
            return _fail(n, f"Could not run test (did you define {', '.join(keys)}?) — {e}")

    results.append(_safe(1, test_problem_1, "word", "length"))
    results.append(_safe(2, test_problem_2, "text", "first_char", "last_char"))
    results.append(_safe(3, test_problem_3, "s", "sub"))
    results.append(_safe(4, test_problem_4, "raw_name", "clean_name"))
    results.append(_safe(5, test_problem_5, "msg", "new_msg"))
    results.append(_safe(6, test_problem_6, "nouns", "verbs", "report"))
    results.append(_safe(7, test_problem_7, "vowels"))
    results.append(_safe(8, test_problem_8, "nums", "first_num", "last_two"))
    results.append(_safe(9, test_problem_9, "items"))
    results.append(_safe(10, test_problem_10, "sentence", "words", "rejoined"))

    passed = sum(bool(x) for x in results)
    total = len(results)
    print(f"\nSummary: {passed}/{total} tests passed.")
    return passed == total
