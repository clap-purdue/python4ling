def _ok(n): 
    print(f"✓ Problem {n} correct")

def _fail(n, m): 
    print(f"✗ Problem {n}: {m}")

def test_problem_1(main_text, num_lines):
    if not isinstance(main_text, str) or len(main_text) < 1000:
        return _fail(1, "main_text is too short (did you remove the header correctly and keep the story text?)")
    if not isinstance(num_lines, int) or num_lines <= 0:
        return _fail(1, "num_lines should be a positive integer (number of lines after removing the header).")
    # simple sanity: after removing header, line count should be smaller than original file
    _ok(1)

def test_problem_2(punctuation, clean_text, main_text):
    if clean_text != clean_text.lower():
        return _fail(2, "clean_text should be lowercase.")
    # punctuation replaced
    for p in punctuation:
        if p in clean_text:
            return _fail(2, f"'{p}' is still in clean_text. Replace punctuation with spaces.")
    # newline removed
    if "\n" in clean_text:
        return _fail(2, "clean_text still contains newline characters (\n). Replace them with spaces.")
    _ok(2)

def test_problem_3(tokens, token_count, type_count, ttr):
    if token_count != len(tokens):
        return _fail(3, "token_count is incorrect. It should equal len(tokens).")
    if type_count != len(set(tokens)):
        return _fail(3, "type_count is incorrect. It should equal len(set(tokens)).")
    if not (0 < ttr <= 1):
        return _fail(3, "ttr should be between 0 and 1. Did you compute type_count / token_count?")
    _ok(3)

def test_problem_4(freq, top10):
    if not isinstance(freq, dict) or len(freq) < 1000:
        return _fail(4, "freq should be a dictionary with many word types.")
    if len(top10) != 10:
        return _fail(4, "top10 should contain 10 (word, count) pairs.")
    counts = [c for _, c in top10]
    if counts != sorted(counts, reverse=True):
        return _fail(4, "top10 should be sorted by count (largest first).")
    _ok(4)

def test_problem_5(names, name_counts, tokens):
    for n in names:
        if n not in name_counts:
            return _fail(5, f"name_counts is missing the key '{n}'.")
        if name_counts[n] != tokens.count(n):
            return _fail(5, f"Count is wrong for '{n}'.")
    _ok(5)

def test_problem_6(longest_words):
    if not isinstance(longest_words, list) or len(longest_words) != 10:
        return _fail(6, "longest_words should be a list of 10 words.")
    lens = [len(w) for w in longest_words]
    if lens != sorted(lens, reverse=True):
        return _fail(6, "longest_words is not sorted by length (longest first).")
    _ok(6)
