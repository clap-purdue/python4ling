"""
Python for Linguistics - Problem Set 1 Tests

Usage in notebook:
    from test_problems import *
    test_problem_1()  # Test individual problems
    run_all_tests()   # Test everything at once
"""

def test_problem_1(nouns, verbs, adjectives, total_words):
    """Test Problem 1: Word Count"""
    try:
        assert nouns == 450, "nouns should be 450"
        assert verbs == 320, "verbs should be 320"
        assert adjectives == 180, "adjectives should be 180"
        assert total_words == 950, "total_words should be 950 (450 + 320 + 180)"
        
        print("✓ PROBLEM 1 CORRECT!")
        print("  You correctly added the three word categories together.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 1: {e}")
        return False
    
def test_problem_2(type1, type2, type3, type4):
    """Test Problem 2: Using type() to check data types"""
    try:
        assert type1 == int, "type1 should be int (the type of 42)"
        assert type2 == str, "type2 should be str (the type of 'hello')"
        assert type3 == float, "type3 should be float (the type of 3.14)"
        assert type4 == bool, "type4 should be bool (the type of True)"
        
        print("✓ PROBLEM 2 CORRECT!")
        print("  type() returns the data type of any value. This is useful for debugging and understanding what kind of data you're working with.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 2: {e}")
        return False
    

def test_problem_3(num1, num2, total):
    """Test function for Problem 3: Adding two numbers after converting to integers"""
    
    result = int(num1) + int(num2)
    assert result == total, f"Expected {total}, but got {result}"
    print(f"✓ Test 1 passed: int('{num1}') + int({num2}) = {result}")
    
    assert int(num1) == 70, f"Expected int(num1) to be 70, got {int(num1)}"
    assert int(num2) == 40, f"Expected int(num2) to be 40, got {int(num2)}"
    print(f"✓ Test 2 passed: Individual conversions correct")
    
    assert isinstance(int(num1), int), "num1 should be converted to int"
    assert isinstance(int(num2), int), "num2 should be converted to int"
    print(f"✓ Test 3 passed: Both values are integers after conversion")
    
    print("✓ PROBLEM 3 CORRECT!")


def test_problem_4(check1, check2, check3):
    """Test Problem 4: isinstance() for type checking"""
    try:
        assert check1 == True, "check1 should be True (100 is an instance of int)"
        assert check2 == False, "check2 should be False ('100' is not an instance of int)"
        assert check3 == True, "check3 should be True (3.14 is an instance of float)"
        assert isinstance(check1, bool) and isinstance(check2, bool) and isinstance(check3, bool)
        
        print("✓ PROBLEM 4 CORRECT!")
        print("  isinstance() checks if a value is of a specific type.")
        print("  It returns True or False, making it perfect for conditional logic.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 4: {e}")
        return False

def test_problem_5(converted1, converted2, converted3):
    """Test Problem 5: Converting to integers with int()"""
    try:
        assert converted1 == 42, "converted1 should be 42 (from '42')"
        assert converted2 == 3, "converted2 should be 3 (from 3.14)"
        assert converted3 == 1, "converted3 should be 1 (from True)"
        assert isinstance(converted1, int) and isinstance(converted2, int) and isinstance(converted3, int)
        
        print("✓ PROBLEM 5 CORRECT!")
        print("  int() converts values to integers. Strings are parsed,")
        print("  floats are truncated (not rounded), and True/False become 1/0.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 5: {e}")
        return False

def test_problem_6(converted1, converted2, converted3):
    """Test Problem 6: Converting to floats with float()"""
    try:
        assert abs(converted1 - 42.0) < 0.01, "converted1 should be 42.0 (from 42)"
        assert abs(converted2 - 3.14) < 0.01, "converted2 should be 3.14 (from '3.14')"
        assert abs(converted3 - 1.0) < 0.01, "converted3 should be 1.0 (from True)"
        assert isinstance(converted1, float) and isinstance(converted2, float) and isinstance(converted3, float)
        
        print("✓ PROBLEM 6 CORRECT!")
        print("  float() converts values to floating-point numbers.")
        print("  It can parse strings with decimals and convert integers and booleans.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 6: {e}")
        return False

def test_problem_7(result1, result2, result3, result4):
    """Test Problem 7: Understanding bool() conversion"""
    try:
        assert result1 == True, "result1 should be True (non-zero numbers are truthy)"
        assert result2 == False, "result2 should be False (0 is falsy)"
        assert result3 == True, "result3 should be True (non-empty strings are truthy)"
        assert result4 == False, "result4 should be False (empty strings are falsy)"
        assert all(isinstance(r, bool) for r in [result1, result2, result3, result4])
        
        print("✓ PROBLEM 7 CORRECT!")
        print("  bool() converts values to True or False.")
        print("  Falsy values: 0, 0.0, '', [], None. Everything else is truthy!")
        return True
    except AssertionError as e:
        print(f"✗ Problem 7: {e}")
        return False

def test_problem_8(name, age, is_student, gpa):
    """Test Problem 8: Type conversions in practice"""
    try:
        assert name == "Alice", "name should be 'Alice'"
        assert age == 25, "age should be 25 (converted from '25')"
        assert is_student == True, "is_student should be True (converted from 'yes')"
        assert abs(gpa - 3.8) < 0.01, "gpa should be 3.8 (converted from '3.8')"
        assert isinstance(name, str) and isinstance(age, int) and isinstance(is_student, bool) and isinstance(gpa, float)
        
        print("✓ PROBLEM 8 CORRECT!")
        print("  Real programs often need to convert user input (strings)")
        print("  to appropriate types. This is called 'type conversion'.")
        return True
    except AssertionError as e:
        print(f"✗ Problem 8: {e}")
        return False
