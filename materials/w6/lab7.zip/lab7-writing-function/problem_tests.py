
def _ok(n): print(f"✓ Problem {n} correct")
def _fail(n,m): print(f"✗ Problem {n}: {m}")

def test_problem_1(fn):
    if not fn("123456789"): return _fail(1,"valid ID failed")
    if fn("123"): return _fail(1,"short ID accepted")
    if fn("12345abcd"): return _fail(1,"non-digit accepted")
    _ok(1)

def test_problem_2(fn):
    if fn("small",False)!=3: return _fail(2,"small wrong")
    if fn("large",True)!=6: return _fail(2,"large+shot wrong")
    _ok(2)

def test_problem_3(fn):
    if fn(95)!="A" or fn(72)!="C" or fn(50)!="F": return _fail(3,"grading wrong")
    _ok(3)

def test_problem_4(fn):
    if abs(fn([2,4,6])-4)>0.001: return _fail(4,"average wrong")
    _ok(4)

def test_problem_5(fn):
    if fn([1,2,3.5])!=6.5: return _fail(5,"cart total wrong")
    _ok(5)

def test_problem_6(avg_fn, grade_fn):
    scores=[80,90]
    avg=avg_fn(scores)
    g=grade_fn(avg)
    if g!="B": return _fail(6,"pipeline wrong")
    _ok(6)
