# Python for Linguistics — Home Lab Tests (Sets, Tuples & Dictionaries)
#
# Usage in notebook:
#     from problem_tests import *
#     test_problem_1(...)          # Test individual problems
#     run_all_tests(globals())     # Test everything at once (optional)

def _pass(n, msg):
    print(f"✓ PROBLEM {n} CORRECT!")
    if msg:
        print(f"  {msg}")
    return True

def _fail(n, msg):
    print(f"✗ Problem {n}: {msg}")
    return False


def test_problem_1(emojis, unique_emojis, num_unique):
    try:
        assert emojis == ['😂', '🔥', '😂', '✨', '🔥', '🔥', '🥲'], "emojis list should match the problem statement."
        assert isinstance(unique_emojis, set), "unique_emojis should be a set (hint: use set(emojis))."
        assert unique_emojis == {'😂', '🔥', '✨', '🥲'}, "unique_emojis should contain each emoji only once."
        assert num_unique == 4, "num_unique should be 4 (hint: use len(unique_emojis))."
        return _pass(1, "Nice! Sets automatically remove duplicates.")
    except AssertionError as e:
        return _fail(1, str(e))


def test_problem_2(fall_courses, spring_courses, all_courses, both_semesters):
    try:
        assert fall_courses == {'LING398', 'LC263', 'STAT525', 'CS590'}, "fall_courses should match the given set."
        assert spring_courses == {'LING398', 'STAT525', 'CS520', 'PSY120'}, "spring_courses should match the given set."
        assert all_courses == {'LING398', 'LC263', 'STAT525', 'CS590', 'CS520', 'PSY120'}, "all_courses should be the union (hint: | or .union())."
        assert both_semesters == {'LING398', 'STAT525'}, "both_semesters should be the intersection (hint: & or .intersection())."
        return _pass(2, "Great! You used union and intersection correctly.")
    except AssertionError as e:
        return _fail(2, str(e))


def test_problem_3(invited, checked_in, missing):
    try:
        assert invited == {'Amy', 'Ben', 'Chen', 'Dana', 'Eli'}, "invited should match the given set."
        assert checked_in == {'Ben', 'Dana', 'Eli'}, "checked_in should match the given set."
        assert missing == {'Amy', 'Chen'}, "missing should be invited - checked_in (hint: use -)."
        return _pass(3, "Good! Set difference finds what's missing.")
    except AssertionError as e:
        return _fail(3, str(e))


def test_problem_4(location, lat, lon):
    try:
        assert isinstance(location, tuple), "location should be a tuple (hint: use parentheses)."
        assert location == (40.4237, -86.9212), "location should be (40.4237, -86.9212)."
        assert lat == 40.4237, "lat should come from unpacking location."
        assert lon == -86.9212, "lon should come from unpacking location."
        return _pass(4, "Perfect! You created and unpacked a tuple.")
    except AssertionError as e:
        return _fail(4, str(e))


def test_problem_5(a, b):
    try:
        assert a == 'right', "After swapping, a should be 'right' (hint: a, b = b, a)."
        assert b == 'left', "After swapping, b should be 'left' (hint: a, b = b, a)."
        return _pass(5, "Nice! Tuple unpacking makes swapping easy.")
    except AssertionError as e:
        return _fail(5, str(e))


def test_problem_6(profile):
    try:
        assert isinstance(profile, dict), "profile should be a dictionary (hint: use {...})."
        assert profile.get('name') == 'Emily', "profile['name'] should be 'Emily'."
        assert profile.get('major') == 'Linguistics', "profile['major'] should be 'Linguistics'."
        assert profile.get('year') == 4, "profile['year'] should be 4."
        return _pass(6, "Great! You created a dictionary with key–value pairs.")
    except AssertionError as e:
        return _fail(6, str(e))


def test_problem_7(prices, cart, total_cost):
    try:
        assert isinstance(prices, dict), "prices should be a dictionary."
        # Must include at least the required items
        for k in ['chips', 'soda', 'cookies', 'popcorn', 'candy']:
            assert k in prices, f"prices is missing the key '{k}'."
        assert abs(prices['chips'] - 2.50) < 1e-9, "prices['chips'] should be 2.50."
        assert abs(prices['soda'] - 1.25) < 1e-9, "prices['soda'] should be 1.25."
        assert abs(prices['cookies'] - 3.00) < 1e-9, "prices['cookies'] should be 3.00."
        assert cart == ['chips', 'cookies', 'soda'], "cart list should match the problem statement."
        expected = prices['chips'] + prices['cookies'] + prices['soda']
        assert abs(total_cost - expected) < 1e-9, "total_cost is incorrect (hint: add prices[item] for each item in cart)."
        return _pass(7, "Nice! Your prices dictionary has extra items, and you summed only what's in the cart.")
    except AssertionError as e:
        return _fail(7, str(e))


def test_problem_8(hours):
    try:
        assert isinstance(hours, dict), "hours should be a dictionary."
        assert hours.get('Mon') == 2, "hours['Mon'] should still be 2."
        assert hours.get('Tue') == 2, "hours['Tue'] should be updated to 2."
        assert hours.get('Wed') == 3, "hours['Wed'] should still be 3."
        assert hours.get('Thu') == 4, "hours should include a new key 'Thu' with value 4."
        return _pass(8, "Good! You updated an existing key and added a new key.")
    except AssertionError as e:
        return _fail(8, str(e))


def test_problem_9(sentence, words, counts):
    try:
        assert sentence == "had had had a better day", "sentence should match the problem statement exactly."
        assert words == ["had", "had", "had", "a", "better", "day"], "words should be sentence.split()."
        assert isinstance(counts, dict), "counts should be a dictionary."
        expected = {'had': 3, 'a': 1, 'better': 1, 'day': 1}
        assert counts == expected, "counts should map each word to its frequency (hint: use words.count('...'))."
        return _pass(9, "Great! You counted repeated words without writing a loop.")
    except AssertionError as e:
        return _fail(9, str(e))


def test_problem_10(usernames, unique_users, name_lengths):
    try:
        assert usernames == ['amy99', 'ben_s', 'amy99', 'chen_liu', 'dana7'], "usernames list should match the problem statement."
        assert isinstance(unique_users, set), "unique_users should be a set (hint: use set(usernames))."
        assert unique_users == {'amy99', 'ben_s', 'chen_liu', 'dana7'}, "unique_users should contain each username once."
        assert isinstance(name_lengths, dict), "name_lengths should be a dictionary."
        expected_lengths = {'amy99': 5, 'ben_s': 5, 'chen_liu': 8, 'dana7': 5}
        assert name_lengths == expected_lengths, "name_lengths should map each username to len(username). (No loop needed.)"
        return _pass(10, "Excellent! You combined a set with a dictionary successfully.")
    except AssertionError as e:
        return _fail(10, str(e))


def run_all_tests(ns):
    """Run all tests using a namespace dict (use globals() from the notebook)."""
    results = []
    def _safe(n, fn, *keys):
        try:
            args = [ns.get(k) for k in keys]
            return fn(*args)
        except Exception as e:
            return _fail(n, f"Could not run test (did you define {', '.join(keys)}?) — {e}")

    results.append(_safe(1, test_problem_1, "emojis", "unique_emojis", "num_unique"))
    results.append(_safe(2, test_problem_2, "fall_courses", "spring_courses", "all_courses", "both_semesters"))
    results.append(_safe(3, test_problem_3, "invited", "checked_in", "missing"))
    results.append(_safe(4, test_problem_4, "location", "lat", "lon"))
    results.append(_safe(5, test_problem_5, "a", "b"))
    results.append(_safe(6, test_problem_6, "profile"))
    results.append(_safe(7, test_problem_7, "prices", "cart", "total_cost"))
    results.append(_safe(8, test_problem_8, "hours"))
    results.append(_safe(9, test_problem_9, "sentence", "words", "counts"))
    results.append(_safe(10, test_problem_10, "usernames", "unique_users", "name_lengths"))

    passed = sum(bool(x) for x in results)
    total = len(results)
    print(f"\nSummary: {passed}/{total} tests passed.")
    return passed == total
