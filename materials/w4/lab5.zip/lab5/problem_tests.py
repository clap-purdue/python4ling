# Python for Linguistics — Control Flow Lab Tests
#
# Usage in notebook:
#     from problem_tests import *
#     test_problem_1(...)          # Test individual problems
#     run_all_tests(globals())     # Test everything at once (optional)

def _pass(n, msg):
    print(f"✓ PROBLEM {n} CORRECT!")
    if msg:
        print(f"  {msg}")
    return True

def _fail(n, msg):
    print(f"✗ Problem {n}: {msg}")
    return False


def test_problem_1(names, greetings):
    try:
        assert names == ['Alex', 'Mina', 'Ravi', 'Sofia'], "names should match the list in the problem."
        assert isinstance(greetings, list), "greetings should be a list (hint: start with greetings = [])."
        expected = ['Hi, Alex!', 'Hi, Mina!', 'Hi, Ravi!', 'Hi, Sofia!']
        assert greetings == expected, "greetings list is incorrect (hint: use append inside a for-loop)."
        return _pass(1, "Nice! You used a loop to build a new list.")
    except AssertionError as e:
        return _fail(1, str(e))


def test_problem_2(minutes, total_minutes):
    try:
        assert minutes == [25, 40, 30, 10, 55], "minutes should match the list in the problem."
        assert total_minutes == 160, "total_minutes should be 160 (hint: start at 0 and add each value)."
        return _pass(2, "Great! Accumulators are how we compute totals in a loop.")
    except AssertionError as e:
        return _fail(2, str(e))


def test_problem_3(score, passed):
    try:
        assert score == 72, "score should be 72."
        assert isinstance(passed, bool), "passed should be a boolean (True/False)."
        assert passed is True, "passed should be True when score >= 60."
        return _pass(3, "Good! Your if/else correctly sets a boolean.")
    except AssertionError as e:
        return _fail(3, str(e))


def test_problem_4(balance, price, message):
    try:
        assert abs(balance - 4.50) < 1e-9, "balance should be 4.50."
        assert abs(price - 5.25) < 1e-9, "price should be 5.25."
        assert message in ["Purchase successful", "Insufficient funds"], "message should be one of the two required strings."
        assert message == "Insufficient funds", "Because balance < price, message should be 'Insufficient funds'."
        return _pass(4, "Nice! You selected the correct message using if/else.")
    except AssertionError as e:
        return _fail(4, str(e))


def test_problem_5(messages, excited_messages):
    try:
        assert messages == ['see you soon', 'wow!', 'ok', 'that is amazing!', 'thanks'], "messages should match the list in the problem."
        assert isinstance(excited_messages, list), "excited_messages should be a list."
        expected = ['wow!', 'that is amazing!']
        assert excited_messages == expected, "excited_messages is incorrect (hint: if '!' in msg)."
        return _pass(5, "Great! You filtered a list using for + if.")
    except AssertionError as e:
        return _fail(5, str(e))


def test_problem_6(words, count_long):
    try:
        assert words == ['cat', 'reading', 'data', 'linguistics', 'fun'], "words should match the list in the problem."
        assert isinstance(count_long, int), "count_long should be an integer."
        assert count_long == 2, "count_long should be 2 (reading, linguistics)."
        return _pass(6, "Nice! You counted items that match a condition.")
    except AssertionError as e:
        return _fail(6, str(e))


def test_problem_7(prices, cheap, expensive):
    try:
        assert prices == [2.50, 6.00, 4.75, 9.25, 3.00], "prices should match the list in the problem."
        assert cheap == [2.50, 4.75, 3.00], "cheap should contain prices < 5.00 (keep the original order)."
        assert expensive == [6.00, 9.25], "expensive should contain prices >= 5.00 (keep the original order)."
        return _pass(7, "Great! You categorized items using if/else inside a loop.")
    except AssertionError as e:
        return _fail(7, str(e))


def test_problem_8(chat, total_messages, question_count, exclaim_count, avg_length):
    try:
        assert chat == ['Are you coming?', 'Yes!', 'I will be there at 7', 'Great!', 'See you soon'], "chat should match the list in the problem."
        assert total_messages == 5, "total_messages should be 5 (hint: len(chat))."
        assert question_count == 1, "question_count should be 1 (only 'Are you coming?')."
        assert exclaim_count == 2, "exclaim_count should be 2 ('Yes!' and 'Great!')."
        assert isinstance(avg_length, float), "avg_length should be a float (hint: total_chars / total_messages)."
        expected_avg = (len('Are you coming?') + len('Yes!') + len('I will be there at 7') + len('Great!') + len('See you soon')) / 5
        assert abs(avg_length - expected_avg) < 1e-9, "avg_length is incorrect (check your total_chars accumulator)."
        return _pass(8, "Excellent! You computed a summary using one loop and a few if statements.")
    except AssertionError as e:
        return _fail(8, str(e))


def run_all_tests(ns):
    """Run all tests using a namespace dict (use globals() from the notebook)."""
    results = []
    def _safe(n, fn, *keys):
        try:
            args = [ns.get(k) for k in keys]
            return fn(*args)
        except Exception as e:
            return _fail(n, f"Could not run test (did you define {', '.join(keys)}?) — {e}")

    results.append(_safe(1, test_problem_1, "names", "greetings"))
    results.append(_safe(2, test_problem_2, "minutes", "total_minutes"))
    results.append(_safe(3, test_problem_3, "score", "passed"))
    results.append(_safe(4, test_problem_4, "balance", "price", "message"))
    results.append(_safe(5, test_problem_5, "messages", "excited_messages"))
    results.append(_safe(6, test_problem_6, "words", "count_long"))
    results.append(_safe(7, test_problem_7, "prices", "cheap", "expensive"))
    results.append(_safe(8, test_problem_8, "chat", "total_messages", "question_count", "exclaim_count", "avg_length"))

    passed = sum(bool(x) for x in results)
    total = len(results)
    print(f"\nSummary: {passed}/{total} tests passed.")
    return passed == total
